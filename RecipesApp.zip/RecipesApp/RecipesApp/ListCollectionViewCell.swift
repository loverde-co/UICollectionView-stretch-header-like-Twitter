//
//  ListCollectionViewCell.swift
//  RecipesApp
//
//  Created by Daniel Arantes Loverde on 5/9/17.
//  Copyright © 2017 Loverde Co. All rights reserved.
//

import UIKit

class ListCollectionViewCell: UICollectionViewCell {
    
}
